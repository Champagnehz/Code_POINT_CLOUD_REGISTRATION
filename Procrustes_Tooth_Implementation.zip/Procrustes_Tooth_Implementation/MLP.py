import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np


# 定义 MLP 模型
class PointCloudToTransformationMLP(nn.Module):
    def __init__(self, input_dim=3, hidden_dim=512, output_dim=6):
        super(PointCloudToTransformationMLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim // 2)
        self.fc3 = nn.Linear(hidden_dim // 2, output_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        return x


# 加载对齐后的点云数据
def load_aligned_data():
    """
    加载对齐后的点云数据和对应的变换参数。
    """
    # 假设数据已经保存为 .npy 文件
    aligned_point_clouds = np.load(
        r'C:\Users\Lenovo\Desktop\Group_research\export\aligned_point_clouds1.npy')  # 形状: (num_samples, 3)
    transformation_params = np.load(
        r'C:\Users\Lenovo\Desktop\Group_research\export\transformation_params1.npy')  # 形状: (num_samples, 6)

    # 打印数据的形状，确认它们是否加载正确
    print(f"Aligned point clouds shape: {aligned_point_clouds.shape}")
    print(f"Transformation params shape: {transformation_params.shape}")

    return aligned_point_clouds, transformation_params


# 准备数据
aligned_point_clouds, transformation_params = load_aligned_data()

# 检查点云数据的形状是否正确
print(f"Point clouds shape before tensor conversion: {aligned_point_clouds.shape}")

# 将数据转换为 tensor
point_clouds = torch.tensor(aligned_point_clouds, dtype=torch.float32)
transformation_params = torch.tensor(transformation_params, dtype=torch.float32)

# 检查转换后的数据形状
print(f"Point clouds shape after tensor conversion: {point_clouds.shape}")

# 将数据分为训练集和测试集
train_ratio = 0.8
num_train = int(train_ratio * point_clouds.shape[0])
train_point_clouds = point_clouds[:num_train]
train_params = transformation_params[:num_train]
test_point_clouds = point_clouds[num_train:]
test_params = transformation_params[num_train:]

# 初始化模型、损失函数和优化器
model = PointCloudToTransformationMLP(input_dim=3)  # 修改输入维度为 3
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练循环
num_epochs = 100
batch_size = 4
for epoch in range(num_epochs):
    model.train()
    for i in range(0, num_train, batch_size):
        # 获取批次数据
        batch_point_clouds = train_point_clouds[i:i + batch_size]
        batch_params = train_params[i:i + batch_size]

        # 前向传播
        pred_params = model(batch_point_clouds)

        # 计算损失
        loss = criterion(pred_params, batch_params)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f"Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}")

# 评估
model.eval()
with torch.no_grad():
    # 展平测试点云
    test_point_clouds_flat = test_point_clouds.view(test_point_clouds.shape[0], -1)
    # 预测变换参数
    pred_params = model(test_point_clouds_flat)
    # 计算测试集上的 MSE 损失
    test_loss = criterion(pred_params, test_params)
    print(f"Test Loss: {test_loss.item():.4f}")

    # 对样本点云应用预测的变换
    sample_point_cloud = test_point_clouds[0]
    sample_pred_params = pred_params[0]
    transformed_point_cloud = apply_transformation(sample_point_cloud, sample_pred_params)
    print("样本点云已变换！")
