import mesh
import trimesh

# 加载Mesh 1
mesh1 = trimesh.load(r"C:\Users\Lenovo\Desktop\Group_research\OneDrive_2025-02-13\Direct IOS Scans of Patients\A1\A1 lower 2013.ply")
points1 = mesh1.vertices

# 加载Mesh 2
mesh2 = trimesh.load(r"C:\Users\Lenovo\Desktop\Group_research\OneDrive_2025-02-13\Direct IOS Scans of Patients\A1\A1 lower 2016.stl")
points2 = mesh2.vertices

# 创建点云对象

pc1 = trimesh.points.PointCloud(points1, colors=[255, 0, 0])  # 红色
pc2 = trimesh.points.PointCloud(points2, colors=[0, 0, 255])  # 蓝色

# 同时显示两个点云
scene = trimesh.Scene([pc1, pc2])
scene.show()