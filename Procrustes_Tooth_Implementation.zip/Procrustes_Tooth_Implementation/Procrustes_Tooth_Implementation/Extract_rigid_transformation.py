import numpy as np
from scipy.spatial import procrustes


def extract_rigid_transformation(X, Y):
    """
    Extracts the rigid transformation (rotation, translation, and scale)
    from the Procrustes-aligned shape.

    Parameters:
    - X: Original shape (N x 3)
    - Y: Aligned shape (N x 3, output of Procrustes)

    Returns:
    - R: Rotation matrix (3x3)
    - s: Scale factor (scalar)
    - t: Translation vector (3,)
    """
    # Center both shapes at the origin
    X_mean = X.mean(axis=0)
    Y_mean = Y.mean(axis=0)
    X_centered = X - X_mean
    Y_centered = Y - Y_mean

    # Compute the optimal rotation using Singular Value Decomposition (SVD)
    U, _, Vt = np.linalg.svd(X_centered.T @ Y_centered)
    R = U @ Vt  # Rotation matrix

    # Ensure R is a proper rotation matrix (det(R) should be 1)
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt

    # Compute the scale factor
    norm_X = np.linalg.norm(X_centered, 'fro')
    norm_Y = np.linalg.norm(Y_centered, 'fro')
    s = norm_Y / norm_X  # Scale

    # Compute translation
    t = Y_mean - s * R @ X_mean

    return R, s, t


