import json
import trimesh  # For loading .ply and .stl files
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.spatial import procrustes
from scipy.linalg import logm
from Extract_rigid_transformation import extract_rigid_transformation

# Function to load 3D mesh from .ply or .stl
def load_mesh(file_path):
    mesh = trimesh.load(file_path)  # Load the triangular mesh
    points = np.array(mesh.vertices)  # Extract vertex coordinates (N, 3)
    return points

# Function to calculate MSE (Mean Squared Error)
def compute_mse(points1, points2):
    return np.mean(np.sum((points1 - points2) ** 2, axis=1))

# Function to load landmarks from .json
def load_landmarks_from_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)  # 读取 JSON 数据

    # 提取 "location" 字段并转换为 NumPy 数组
    landmarks = np.array([item["location"] for item in data])

    return landmarks  # 返回形状为 (M, 3) 的 NumPy 数组

# Function to convert rotation matrix to Euler angles (in radians)
def rotation_matrix_to_euler_angles(R):
    """
    将旋转矩阵转换为欧拉角（弧度）。
    """
    sy = np.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6

    if not singular:
        rx = np.arctan2(R[2, 1], R[2, 2])
        ry = np.arctan2(-R[2, 0], sy)
        rz = np.arctan2(R[1, 0], R[0, 0])
    else:
        rx = np.arctan2(-R[1, 2], R[1, 1])
        ry = np.arctan2(-R[2, 0], sy)
        rz = 0

    return np.array([rx, ry, rz])

# Load ROI landmarks from .json files
landmarks1 = load_landmarks_from_json(r"C:\Users\Lenovo\Desktop\Group_research\export\empty\empty2013_all_locations.json")  # Shape (M,3)
landmarks2 = load_landmarks_from_json(r"C:\Users\Lenovo\Desktop\Group_research\export\empty\empty2016_all_locations.json")  # Shape (M,3)

# Ensure both landmarks are represented as M×3 matrices
assert landmarks1.shape == landmarks2.shape, "The number of landmarks should be matched"

# Load teeth mesh data from .ply and .stl files
teeth1 = load_mesh(r"C:\Users\Lenovo\Desktop\Group_research\A1 lower 2013.ply")  # First teeth model
teeth2 = load_mesh(r"C:\Users\Lenovo\Desktop\Group_research\A1 lower 2016.stl")  # Second teeth model

# Perform Procrustes alignment on landmarks
m1, m2, disparity = procrustes(landmarks1, landmarks2)

# Output the result
print("Original landmarks1 (first 10 points):\n", landmarks1[:10])
print("Aligned m1 (first 10 points):\n", m1[:10])

# Extract the rigid transformation parameters (rotation, scaling, and translation)
R1, s1, t1 = extract_rigid_transformation(landmarks1, m1)
R2, s2, t2 = extract_rigid_transformation(landmarks2, m2)

# Print global rigid transformation components
print("Rotation matrixes (R1,R2):\n", R1, R2)
print("Scaling factors (s1,s2):", s1, s2)
print("Translation vectors (t1,t2):", t1, t2)

# Convert rotation matrix to Euler angles (in radians)
euler_angles1 = rotation_matrix_to_euler_angles(R1)
euler_angles2 = rotation_matrix_to_euler_angles(R2)

# Combine translation and rotation into a single transformation parameter vector
transformation_params1 = np.concatenate([t1, euler_angles1])  # [tx, ty, tz, rx, ry, rz]
transformation_params2 = np.concatenate([t2, euler_angles2])  # [tx, ty, tz, rx, ry, rz]

# Save transformation parameters to .npy files
np.save(r'C:\Users\Lenovo\Desktop\Group_research\export\transformation_params1.npy', transformation_params1)
np.save(r'C:\Users\Lenovo\Desktop\Group_research\export\transformation_params2.npy', transformation_params2)

# Apply the rigid transformation to whole datasets
teeth1_transformed = s1 * (teeth1 @ R1.T) + t1
teeth2_transformed = s1 * (teeth2 @ R1.T) + t1

# Save aligned point clouds to .npy files
np.save(r'C:\Users\Lenovo\Desktop\Group_research\export\aligned_point_clouds1.npy', teeth1_transformed)
np.save(r'C:\Users\Lenovo\Desktop\Group_research\export\aligned_point_clouds2.npy', teeth2_transformed)

# Compute the MSE (expected to be close to 0 if properly aligned)
mse_original = compute_mse(teeth1, teeth2)
mse_transformed = compute_mse(teeth1_transformed, teeth2_transformed)

print(f"Original MSE (before transformation): {mse_original:.6f}")
print(f"Transformed MSE (after alignment): {mse_transformed:.6f}")