import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Load point clouds
src = np.load(r'D:\Group_research_project_paper\Group_research\src_pts.npy')  # Shape: [1, N, 3]
tgt = np.load(r'D:\Group_research_project_paper\Group_research\tgt_pts.npy')  # Shape: [1, N, 3]

# Remove batch dimension
src = src[0]
tgt = tgt[0]

# Plot
fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

ax.scatter(src[:, 0], src[:, 1], src[:, 2], c='red', label='Source (src)', alpha=0.7)
ax.scatter(tgt[:, 0], tgt[:, 1], tgt[:, 2], c='blue', label='Target (tgt)', alpha=0.7)

ax.set_title("Initial Point Cloud Comparison")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
ax.legend()

plt.tight_layout()
plt.show()
