import numpy as np
import matplotlib.pyplot as plt

# === 模型预测的旋转矩阵 R 和 平移向量 t ===
R_model = np.array([
    [ 0.9038884,  -0.38423938,  0.18800569],
    [ 0.2746772,   0.858267,     0.43350977],
    [-0.32793048, -0.34020358,  0.8813191 ]
], dtype=np.float32)

t_model = np.array([0.01154375, -0.00178297, -0.0047601], dtype=np.float32)

# === ICP 微调后的变换矩阵 ===
T_icp = np.array([
    [ 0.28239776, -0.69876046,  0.6572559,  -0.67618477],
    [ 0.66123771,  0.63816213,  0.39435236,  4.05785981],
    [-0.69499366,  0.32323816,  0.64226233,  1.46558571],
    [ 0.0,         0.0,         0.0,         1.0]
], dtype=np.float32)

# === 加载关键点 ===
src_pts = np.load("D:/Group_research_project_paper/Group_research/src_pts.npy")[0]  # shape [N, 3]
tgt_pts = np.load("D:/Group_research_project_paper/Group_research/tgt_pts.npy")[0]  # shape [N, 3]

# === 应用模型预测变换 ===
src_model_aligned = (R_model @ src_pts.T).T + t_model

# === 应用 ICP 总变换 ===
src_homo = np.hstack((src_model_aligned, np.ones((src_model_aligned.shape[0], 1))))
src_icp_aligned = (T_icp @ src_homo.T).T[:, :3]

# === 可视化 ===
fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

ax.scatter(tgt_pts[:, 0], tgt_pts[:, 1], tgt_pts[:, 2], c='gray', label='Target', marker='x')
ax.scatter(src_pts[:, 0], src_pts[:, 1], src_pts[:, 2], c='red', label='Original Source', alpha=0.4)
ax.scatter(src_model_aligned[:, 0], src_model_aligned[:, 1], src_model_aligned[:, 2],
           c='blue', label='Model Aligned', alpha=0.7)
ax.scatter(src_icp_aligned[:, 0], src_icp_aligned[:, 1], src_icp_aligned[:, 2],
           c='green', label='ICP Refined', alpha=0.9)

ax.set_title("Keypoint Alignment Comparison (3D)")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
ax.legend()
plt.tight_layout()
plt.show()
