import json
import numpy as np

def load_json_points(filepath):
    """从 JSON 文件中提取 'location' 点坐标"""
    with open(filepath, 'r') as f:
        data = json.load(f)
    coords = [item['location'] for item in data]
    return np.array(coords, dtype=np.float32)

def save_to_npy(json_2013_path, json_2016_path, save_dir="./"):
    # 加载关键点
    src_pts = load_json_points(json_2013_path)
    tgt_pts = load_json_points(json_2016_path)

    # 扩展为 [B, N, 3]，便于模型输入
    src_pts_batch = np.expand_dims(src_pts, axis=0)
    tgt_pts_batch = np.expand_dims(tgt_pts, axis=0)

    # 保存为 .npy
    np.save(f"{save_dir}/src_pts.npy", src_pts_batch)
    np.save(f"{save_dir}/tgt_pts.npy", tgt_pts_batch)
    print("保存成功：src_pts.npy, tgt_pts.npy")

# 示例调用（修改路径为你实际的路径）
if __name__ == "__main__":
    save_to_npy("Thea_02_lower13.json", "Thea_02_lower16.json")
