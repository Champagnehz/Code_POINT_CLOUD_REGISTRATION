import json
import numpy as np
import os

def load_json_points(filepath):
    """从 JSON 文件中提取 'location' 点坐标"""
    with open(filepath, 'r') as f:
        data = json.load(f)
    coords = [item['location'] for item in data]
    return np.array(coords, dtype=np.float32)

def merge_and_save(json_2013_paths, json_2016_paths, save_dir="./"):
    """
    加载多组 2013 和 2016 的点，保持顺序合并并保存为 .npy 文件
    """
    assert len(json_2013_paths) == len(json_2016_paths), "2013 和 2016 文件数必须一致"

    all_src_pts = []
    all_tgt_pts = []

    for src_path, tgt_path in zip(json_2013_paths, json_2016_paths):
        src_pts = load_json_points(src_path)
        tgt_pts = load_json_points(tgt_path)
        assert src_pts.shape == tgt_pts.shape, f"点数不匹配: {src_path} vs {tgt_path}"
        all_src_pts.append(src_pts)
        all_tgt_pts.append(tgt_pts)

    # 拼接为整体数组并加 batch 维度
    src_all = np.concatenate(all_src_pts, axis=0)[None, ...]  # [1, N, 3]
    tgt_all = np.concatenate(all_tgt_pts, axis=0)[None, ...]  # [1, N, 3]

    np.save(os.path.join(save_dir, "src_pts.npy"), src_all)
    np.save(os.path.join(save_dir, "tgt_pts.npy"), tgt_all)
    print("✅ 融合并保存完成：src_pts.npy, tgt_pts.npy")
    print(f"src shape: {src_all.shape}, tgt shape: {tgt_all.shape}")

if __name__ == "__main__":
    # 按照组顺序填写：02、04、08（请确保路径顺序正确）
    json_2013_files = [
        "Thea_02_lower13.json",
        "Thea_04_lower13.json",
        "08_2013_landmarks.json"  # <== 需要你提供或命名
    ]
    json_2016_files = [
        "Thea_02_lower16.json",
        "Thea_04_lower16.json",
        "08_2016_landmarks.json"  # <== 需要你提供或命名
    ]

    merge_and_save(json_2013_files, json_2016_files, save_dir="./")
