import torch
import torch.nn as nn
import torch.nn.functional as F


# Enhanced EdgeConv (DGCNN style)
class EdgeConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(EdgeConv, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_channels * 2, out_channels),
            nn.LayerNorm(out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, out_channels),
            nn.LayerNorm(out_channels),
            nn.ReLU()
        )

    def forward(self, x, knn_idx):
        B, N, C = x.shape
        k = knn_idx.shape[-1]

        idx_base = torch.arange(0, B, device=x.device).view(-1, 1, 1) * N
        knn_idx = knn_idx + idx_base
        knn_idx = knn_idx.view(-1)

        x_flat = x.view(B * N, -1)
        neighbors = x_flat[knn_idx, :].view(B, N, k, C)
        x_central = x.unsqueeze(2).expand(-1, -1, k, -1)
        edge_features = torch.cat([x_central, neighbors - x_central], dim=-1)

        edge_features = edge_features.view(B * N * k, -1)
        edge_features = self.mlp(edge_features)
        edge_features = edge_features.view(B, N, k, -1)
        return edge_features.max(dim=2)[0]


# Upgraded GCN model (LayerNorm version, compatible with batch=1)
class GCNRegistrationModel(nn.Module):
    def __init__(self, k=10):
        super(GCNRegistrationModel, self).__init__()
        self.k = k
        self.edgeconv1 = EdgeConv(3, 64)
        self.edgeconv2 = EdgeConv(64, 128)
        self.edgeconv3 = EdgeConv(128, 256)

        self.fc = nn.Sequential(
            nn.Linear(1792, 512),
            nn.LayerNorm(512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.LayerNorm(256),
            nn.ReLU(),
            nn.Linear(256, 12)  # Output 9-dim R, 3-dim t
        )

    def get_knn(self, x):
        B, N, C = x.shape
        inner = -2 * torch.matmul(x, x.transpose(2, 1))
        xx = torch.sum(x ** 2, dim=2, keepdim=True)
        pairwise_distance = -xx - inner - xx.transpose(2, 1)
        _, idx = pairwise_distance.topk(k=self.k, dim=-1)
        return idx

    def forward(self, src, tgt):
        knn_src = self.get_knn(src)
        knn_tgt = self.get_knn(tgt)

        feat_src1 = self.edgeconv1(src, knn_src)
        feat_src2 = self.edgeconv2(feat_src1, knn_src)
        feat_src3 = self.edgeconv3(feat_src2, knn_src)
        src_global = torch.cat([feat_src1, feat_src2, feat_src3], dim=-1)
        src_feat = torch.cat([src_global.max(dim=1)[0], src_global.mean(dim=1)], dim=-1)

        feat_tgt1 = self.edgeconv1(tgt, knn_tgt)
        feat_tgt2 = self.edgeconv2(feat_tgt1, knn_tgt)
        feat_tgt3 = self.edgeconv3(feat_tgt2, knn_tgt)
        tgt_global = torch.cat([feat_tgt1, feat_tgt2, feat_tgt3], dim=-1)
        tgt_feat = torch.cat([tgt_global.max(dim=1)[0], tgt_global.mean(dim=1)], dim=-1)

        feat = torch.cat([src_feat, tgt_feat], dim=-1)
        out = self.fc(feat)

        # Parse output
        R_raw = out[:, :9].view(-1, 3, 3)
        t = out[:, 9:].view(-1, 3, 1)

        # We'll let the RegistrationWrapper handle the SVD correction
        # to avoid duplication of efforts and potential conflicts
        return R_raw, t