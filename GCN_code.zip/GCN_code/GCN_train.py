import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import open3d as o3d
from GCN_model import GCNRegistrationModel
import numpy as np
import matplotlib.pyplot as plt
# === Enable anomaly detection to trace inplace operation errors ===
torch.autograd.set_detect_anomaly(True)

def icp_refine(aligned_points_np, target_mesh_path, threshold=5.0, sample_points=5000):
    """
    对初始对齐点云执行 ICP 微调
    :param aligned_points_np: 模型预测后对齐的源点云 (numpy array)
    :param target_mesh_path: 目标 STL 文件路径
    :param threshold: 最大配准距离
    :param sample_points: 从 STL 采样的点数
    :return: 精细对齐后的点云和最终的变换矩阵（4x4）
    """
    # 转换为 open3d 点云
    src_pcd = o3d.geometry.PointCloud()
    src_pcd.points = o3d.utility.Vector3dVector(aligned_points_np)

    # 载入目标 STL 并采样点
    target_mesh = o3d.io.read_triangle_mesh(target_mesh_path)
    target_mesh.compute_vertex_normals()
    tgt_pcd = target_mesh.sample_points_uniformly(number_of_points=sample_points)

    # ICP 配准
    icp_result = o3d.pipelines.registration.registration_icp(
        src_pcd,
        tgt_pcd,
        threshold,
        np.eye(4),
        o3d.pipelines.registration.TransformationEstimationPointToPoint()
    )

    print("✔ ICP 优化完成，变换矩阵:")
    print(icp_result.transformation)

    # 应用 ICP 变换
    src_pcd.transform(icp_result.transformation)
    return src_pcd, icp_result.transformation

# === Ensure model output is a valid rotation matrix ===
class RegistrationWrapper(nn.Module):
    def __init__(self, model):
        super(RegistrationWrapper, self).__init__()
        self.model = model

    def forward(self, src, tgt):
        # Ensure input shapes are correct
        if len(src.shape) > 3:
            src = src.squeeze(1)
        if len(tgt.shape) > 3:
            tgt = tgt.squeeze(1)

        # Original output
        R_raw, t = self.model(src, tgt)

        # Process for each batch - FIXED to avoid inplace operations
        batch_size = R_raw.shape[0]
        corrected_Rs = []

        for i in range(batch_size):
            R_mat = R_raw[i].view(3, 3)
            # SVD decomposition
            U, S, V = torch.svd(R_mat)
            # Ensure it's a proper rotation matrix (no inplace operations)
            R_ortho = torch.matmul(U, V.transpose(0, 1))
            # Ensure determinant is 1
            det = torch.det(R_ortho)
            if det < 0:
                # Create a new tensor instead of modifying V inplace
                V_fixed = V.clone()
                # Use a new tensor assignment, not inplace modification
                new_col = -V_fixed[:, 2]
                V_fixed = torch.cat([V_fixed[:, :2], new_col.unsqueeze(1)], dim=1)
                R_ortho = torch.matmul(U, V_fixed.transpose(0, 1))
            corrected_Rs.append(R_ortho)

        R_final = torch.stack(corrected_Rs).view(batch_size, 3, 3)
        return R_final, t

def normalize_points(pts):
    center = pts.mean(dim=1, keepdim=True)
    scale = pts.std(dim=1, keepdim=True)
    return (pts - center) / (scale + 1e-8)

# === Chamfer distance implementation ===
def chamfer_distance(src, tgt):
    # Expand for batch matrix multiplication
    src_expanded = src.unsqueeze(2)  # [B,N,1,3]
    tgt_expanded = tgt.unsqueeze(1)  # [B,1,M,3]

    # Calculate Euclidean distance
    dist = torch.sum((src_expanded - tgt_expanded) ** 2, dim=3)  # [B,N,M]

    # Calculate minimum distances
    min_dist_src_tgt = torch.min(dist, dim=2)[0]  # [B,N]
    min_dist_tgt_src = torch.min(dist, dim=1)[0]  # [B,M]

    # Chamfer distance
    chamfer_dist = torch.mean(min_dist_src_tgt) + torch.mean(min_dist_tgt_src)
    return chamfer_dist


# === Load data ===
def load_sample_data():
    # Update these paths to your actual file locations
    src = np.load(r'D:/Group_research_project_paper/Group_research/src_pts.npy')
    tgt = np.load(r'D:/Group_research_project_paper/Group_research/tgt_pts.npy')


    # Print original shapes
    print(f"Raw source shape: {src.shape}")
    print(f"Raw target shape: {tgt.shape}")

    # Ensure data format is correct
    if len(src.shape) > 2:
        src = src.reshape(-1, 3)  # Flatten to [N, 3]
    if len(tgt.shape) > 2:
        tgt = tgt.reshape(-1, 3)  # Flatten to [N, 3]

    # Add batch dimension
    src_tensor = torch.tensor(src, dtype=torch.float32).unsqueeze(0)  # [1,N,3]
    tgt_tensor = torch.tensor(tgt, dtype=torch.float32).unsqueeze(0)  # [1,M,3]

    # Print processed shapes
    print(f"Processed source shape: {src_tensor.shape}")
    print(f"Processed target shape: {tgt_tensor.shape}")

    # Print statistics to verify data
    print(f"Source mean: {torch.mean(src_tensor)}, std: {torch.std(src_tensor)}")
    print(f"Target mean: {torch.mean(tgt_tensor)}, std: {torch.std(tgt_tensor)}")

    return src_tensor, tgt_tensor


# === Apply transformation ===
def apply_transform(points, R, t):
    # Ensure inputs are tensors
    if not isinstance(points, torch.Tensor):
        points = torch.tensor(points, dtype=torch.float32)
    if not isinstance(R, torch.Tensor):
        R = torch.tensor(R, dtype=torch.float32)
    if not isinstance(t, torch.Tensor):
        t = torch.tensor(t, dtype=torch.float32)

    # Make sure t is correctly shaped for broadcasting
    if len(t.shape) == 1:
        t = t.reshape(1, 3)

    # Apply transformation
    points_transformed = torch.matmul(points, R.transpose(0, 1)) + t

    # If input was numpy array, return numpy result
    if isinstance(points, np.ndarray):
        return points_transformed.numpy()
    return points_transformed


# === Initialization ===
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Debug info
print("Initializing model...")
base_model = GCNRegistrationModel(k=20).to(device)
model = RegistrationWrapper(base_model).to(device)

# Check model parameters
total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"Total parameters: {total_params}")
print(f"Trainable parameters: {trainable_params}")

# Use higher learning rate and weight decay
optimizer = optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=50, verbose=True)

# === Load and prepare data ===
print("Loading data...")
src_pts, tgt_pts = load_sample_data()
src_pts = src_pts.to(device)
tgt_pts = tgt_pts.to(device)
print("normalize data...")
src_pts = normalize_points(src_pts)
tgt_pts = normalize_points(tgt_pts)
# === Training loop ===
print("Starting training...")
best_loss = float('inf')
for epoch in range(1000):
    # Zero gradients
    model.train()
    optimizer.zero_grad()

    # Forward pass
    R, t = model(src_pts, tgt_pts)

    # Apply transformation - FIXED to handle t shape correctly
    # Make sure t is correctly shaped for bmm operation
    t_reshaped = t.view(t.size(0), 1, 3)
    src_transformed = torch.bmm(src_pts, R.transpose(1, 2)) + t_reshaped

    # Calculate loss
    loss_mse = nn.MSELoss()(src_transformed, tgt_pts)
    loss_cd = chamfer_distance(src_transformed, tgt_pts)

    # Add orthogonality loss
    batch_size = R.shape[0]
    identity = torch.eye(3, device=device).unsqueeze(0).expand(batch_size, -1, -1)
    loss_ortho = torch.norm(torch.bmm(R, R.transpose(1, 2)) - identity, dim=(1, 2)).mean()

    # Total loss
    loss = loss_mse + 0.1 * loss_cd + 0.01 * loss_ortho

    # Backward pass and optimization
    loss.backward()

    # Debug: Check gradients
    if epoch == 0 or epoch % 100 == 0:
        has_grad = False
        for name, param in model.named_parameters():
            if param.grad is not None and torch.sum(torch.abs(param.grad)) > 0:
                has_grad = True
                print(f"Parameter {name} has gradient: min={param.grad.min().item()}, max={param.grad.max().item()}")
        if not has_grad:
            print("WARNING: No gradients flowing!")

    # Gradient clipping and update
    torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
    optimizer.step()
    scheduler.step(loss)

    # Print progress
    if epoch % 10 == 0:
        print(
            f"Epoch {epoch} | Loss: {loss.item():.6f} | MSE: {loss_mse.item():.6f} | CD: {loss_cd.item():.6f} | Ortho: {loss_ortho.item():.6f}")

    # Save best model
    if loss < best_loss:
        best_loss = loss
        torch.save({
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': best_loss,
            'epoch': epoch
        }, 'best_registration_model.pth')

# === Load best model and apply ===
print("Training completed, loading best model...")
checkpoint = torch.load('best_registration_model.pth')
model.load_state_dict(checkpoint['model_state_dict'])
model.eval()

# Get final results
with torch.no_grad():
    R_final, t_final = model(src_pts, tgt_pts)

# Convert to numpy
R_np = R_final[0].cpu().numpy()
t_np = t_final[0].cpu().numpy().flatten()  # Make sure t is flattened correctly
print("Final Rotation Matrix R:")
print(R_np)
print("Final Translation Vector t:")
print(t_np)
print("det(R):", np.linalg.det(R_np))


# === Apply to full point cloud ===
print("Loading and transforming full point cloud...")
# Update this path to your actual file location
full_pcd = o3d.io.read_point_cloud(r"D:/Group_research_project_paper/Group_research/A1 lower 2013.ply")
full_points = np.asarray(full_pcd.points)
aligned_points = apply_transform(full_points, R_np, t_np)

#ICP
refined_pcd, transformation_icp = icp_refine(
    aligned_points_np=aligned_points,
    target_mesh_path="D:/Group_research_project_paper/Group_research/A1 lower 2016.stl",
    threshold=5.0
)

# === Visualization and save ===
aligned_pcd = o3d.geometry.PointCloud()
aligned_pcd.points = o3d.utility.Vector3dVector(aligned_points)
aligned_pcd.paint_uniform_color([1, 0.706, 0])
refined_pcd.paint_uniform_color([1, 0.706, 0])
print("Loading target mesh for visualization...")
# Update this path to your actual file location
target_mesh = o3d.io.read_triangle_mesh(r"D:/Group_research_project_paper/Group_research/A1 lower 2016.stl")
target_mesh.compute_vertex_normals()
target_mesh.paint_uniform_color([0.5, 0.5, 0.5])


print("保存 ICP 微调后的点云...")
o3d.io.write_point_cloud("D:/Group_research_project_paper/Group_research/A1_2013_aligned_icp.ply", refined_pcd)

print("Saving aligned point cloud...")
# Update this path to your desired output location
o3d.io.write_point_cloud(r"D:/Group_research_project_paper/Group_research/A1_2013_aligned.ply", aligned_pcd)

# print("Showing visualization...")
# o3d.visualization.draw_geometries([aligned_pcd, target_mesh],
#                                   window_name="Aligned Result",
#                                   point_show_normal=False)
print("ICP显示最终对齐结果...")
o3d.visualization.draw_geometries([refined_pcd, target_mesh], window_name="After ICP")


