import trimesh
import numpy as np
import json


# Read the position data of empty objects
with open('C:/Users/Lenovo/Desktop/Group_research/export/empty/empty2013_all_test.json', 'r') as json_file:
    data = json.load(json_file)

# Print all the data of the empty objects
print("Empty object data:")
print(data)

# Get the locations (keypoints) of all empty objects
keypoints = np.array([entry['location'] for entry in data])
print("Keypoints:")
print(keypoints)

# Print the number of empty objects
print(f"Number of empty objects: {len(data)}")  # Print the number of empty objects

# Load the PLY file (mesh)
mesh = trimesh.load_mesh('C:/Users/Lenovo/Desktop/Group_research/export/A1_lower2.ply')

# Get the mesh vertices and faces data
vertices = mesh.vertices
faces = mesh.faces

# Print the vertices data
print("Vertices:")
print(vertices)

# Clear any existing vertex colors
mesh.visual.vertex_colors = np.zeros((vertices.shape[0], 4))  # Set to no color

# Create a new color array, setting it to be the same size as the number of vertices
colors = np.ones((vertices.shape[0], 4))  # Each vertex has 4 RGBA values
# Set black color (R=0, G=0, B=0, A=1)
black = [0, 0, 0, 1]
colors[:] = black

# Set a distance threshold
distance_threshold = 1.2  # Set a threshold (e.g., vertices within 1.2 units)

# Loop through all keypoints, calculate the distance, and set the color for the nearest vertices
for kp in keypoints:
    # Calculate the Euclidean distance from each vertex to the keypoint
    distances = np.linalg.norm(vertices - kp, axis=1)  # Calculate the distance from each vertex to the keypoint

    # Set vertices within the threshold distance to red
    close_indices = distances < distance_threshold
    colors[close_indices] = [1, 0, 0, 1]  # Red (R=1, G=0, B=0, A=1)

# Apply the colors to the mesh
mesh.visual.vertex_colors = colors

# Create circles to represent keypoints, set the radius to 0.5
keypoint_circles = []
circle_radius = 0.5  # Circle radius

# Create the vertices for the circle
num_vertices = 10  # Number of vertices for the circle to approximate it
theta = np.linspace(0, 2 * np.pi, num_vertices)  # Angles from 0 to 2π
x = circle_radius * np.cos(theta)  # Calculate the X coordinates of the circle
y = circle_radius * np.sin(theta)  # Calculate the Y coordinates of the circle
z = np.zeros_like(x)  # Z coordinates for the circle, set to 0

# Convert the circle's vertices to 3D space
circle_vertices = np.vstack([x, y, z]).T

# Create a red circle for each keypoint
for kp in keypoints:
    # Create a polygon representing the circle (a triangular mesh)
    circle = trimesh.Trimesh(vertices=circle_vertices,
                             faces=[[i, (i + 1) % num_vertices, (i + 2) % num_vertices] for i in
                                    range(num_vertices - 2)])
    circle.apply_translation(kp)  # Move the circle to the keypoint location
    circle.visual.vertex_colors = [1, 0, 0, 1]  # Set the circle color to red (RGBA)
    keypoint_circles.append(circle)

# Add the mesh and circles to the same scene for visualization
scene = trimesh.scene.Scene()
scene.add_geometry(mesh)  # Add the mesh to the scene
for circle in keypoint_circles:
    scene.add_geometry(circle)  # Add each circle to the scene

# Set the camera view
scene.camera.position = [0, 0, 100]  # Set the camera position to ensure the objects are visible
scene.camera.look_at(np.array([[0, 0, 0]]))  # Camera looks at the center of the scene to ensure all objects are visible

# Show the scene, including the mesh and the red circles representing the keypoints
scene.show()
