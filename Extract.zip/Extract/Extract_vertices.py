import csv
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
matplotlib.use('TkAgg')
import json
import csv


def json_to_csv(json_file, csv_file):
    # 读取JSON文件
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # 打开CSV文件以进行写入
    with open(csv_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())

        # 写入表头
        writer.writeheader()

        # 写入数据
        writer.writerows(data)


# 使用示例
json_file = 'C:/Users/Lenovo/Desktop/Group_research/export/empty/empty2013_all_test.json'  # JSON文件路径
csv_file = 'C:/Users/Lenovo/Desktop/Group_research/export/empty/empty2013_all_test.csv'  # 输出CSV文件路径

json_to_csv(json_file, csv_file)


# 读取CSV文件中的3D点数据
def read_csv(file_path):
    x_vals = []
    y_vals = []
    z_vals = []

    with open(file_path, 'r') as file:
        csv_reader = csv.reader(file)
        header = next(csv_reader)  # 跳过表头
        for row in csv_reader:
            x_vals.append(float(row[0]))  # 假设第1列是x
            y_vals.append(float(row[1]))  # 假设第2列是y
            z_vals.append(float(row[2]))  # 假设第3列是z

    return x_vals, y_vals, z_vals


# 设置CSV文件路径
csv_file_path = r"C:/Users/Lenovo/Desktop/Group_research/export/empty/empty2013_all_test.csv"

# 读取点数据
x, y, z = read_csv(csv_file_path)

# 创建一个3D图形
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 绘制3D散点图
ax.scatter(x, y, z, c='r', marker='o', s=1)  # s=1设置点的大小

# 设置坐标轴标签
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# 显示图形
plt.show()
plt.pause(0.1)
