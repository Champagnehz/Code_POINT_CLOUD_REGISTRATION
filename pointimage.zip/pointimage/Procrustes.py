import pandas as pd
import numpy as np
from scipy.spatial import procrustes
import json
# Read the first CSV file and extract the coordinates
# Assume the CSV file has 'x', 'y', 'z' columns representing coordinates
# df1 = pd.read_csv(r"D:\pointimage\A.csv")  # Modify with your file path
# keypoints1 = df1[['x', 'y', 'z']].values  # Extract the coordinate columns and convert to numpy array
#
# # Read the second CSV file and extract the coordinates
# df2 = pd.read_csv(r"D:\pointimage\B.csv")  # Modify with your file path
# keypoints2 = df2[['x', 'y', 'z']].values  # Extract the coordinate columns and convert to numpy array

# Read the first JSON file and extract the coordinates
# Assume the JSON file has 'location' keys for coordinates
with open(r"C:\Users\Lenovo\Desktop\Group_research\export\empty\inside2013_14_locations.json", "r") as file:  # Modify with your file path
    data1 = json.load(file)
keypoints1 = np.array([entry['location'] for entry in data1])  # Extract 'location' and convert to numpy array

# Read the second JSON file and extract the coordinates
with open(r"C:\Users\Lenovo\Desktop\Group_research\export\empty\inside2016_14_locations.json", "r") as file:  # Modify with your file path
    data2 = json.load(file)
keypoints2 = np.array([entry['location'] for entry in data2])  # Extract 'location' and convert to numpy array


# Perform Procrustes alignment
mtx1, mtx2, disparity = procrustes(keypoints1, keypoints2)

# Output the results
print("Aligned X:\n", mtx1)  # This is the aligned version of keypoints1
print("Target Y:\n", mtx2)  # This is the target keypoints2
print("Alignment Error:", disparity)  # This is the alignment error between the two sets
