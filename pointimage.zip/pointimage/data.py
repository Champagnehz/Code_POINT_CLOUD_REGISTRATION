import pandas as pd

# 定义 A 和 B 的坐标数据
A_data = [
    [-37.13, -4.92, 2.78],
    [-12.83, 32.24, 15.95],
    [-40.93, -12.05, 16.93],
    [-2.98, -65.36, 31.10],
    [-9.12, -30.96, 54.91]
]

B_data = [
    [-33.91, -3.77, 3.79],
    [-12.00, 32.08, 26.35],
    [-39.13, -9.13, 24.28],
    [-7.38, -56.69, 35.63],
    [-6.95, -28.63, 55.94]
]

# 创建 A 和 B 的 DataFrame
A_df = pd.DataFrame(A_data, columns=['x', 'y', 'z'])
B_df = pd.DataFrame(B_data, columns=['x', 'y', 'z'])

# 将 DataFrame 保存为 CSV 文件
A_df.to_csv('A.csv', index=False)
B_df.to_csv('B.csv', index=False)

print("CSV 文件已生成：A.csv 和 B.csv")
