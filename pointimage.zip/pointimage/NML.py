import nibabel as nib
import numpy as np
import os

def load_surface_mesh(file_path):
    """
    Load a surface mesh from a given file using nibabel.
    
    Parameters:
        file_path (str): Path to the surface mesh file.
    
    Returns:
        tuple: vertices (numpy.ndarray), faces (numpy.ndarray), triangles (numpy.ndarray)
    """
    try:
        # Load the surface file
        surf = nib.load(file_path)
        
        # Extract vertices (pointset) and faces (triangle indices)
        vertices = surf.agg_data('pointset')
        faces = surf.agg_data('triangle')
        
        # Form the triangles using the face indices
        triangles = vertices[faces]
        
        return vertices, faces, triangles
    except Exception as e:
        print(f"Error loading surface mesh: {e}")
        return None, None, None

def process_directory(directory_path):
    """
    Process all surface mesh files in a directory.
    
    Parameters:
        directory_path (str): Path to the directory containing surface mesh files.
    """
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        if os.path.isfile(file_path) and file_name.endswith(".gii"):
            print(f"Processing file: {file_name}")
            vertices, faces, triangles = load_surface_mesh(file_path)
            if vertices is not None:
                print(f"{file_name} - Vertices shape: {vertices.shape}, Faces shape: {faces.shape}, Triangles shape: {triangles.shape}")
            else:
                print(f"Failed to load {file_name}")

# Example usage
if __name__ == "__main__":
    directory_path = r'C:\Users\User\Desktop\group project\新生儿 dHCP 数据\session_1'
    process_directory(directory_path)
