import nibabel as nib
import numpy as np
import os

def load_surface_mesh(file_path):
    """
    Load a surface mesh from a given file using nibabel.
    
    Parameters:
        file_path (str): Path to the surface mesh file.
    
    Returns:
        tuple: vertices (numpy.ndarray), faces (numpy.ndarray), triangles (numpy.ndarray)
    """
    try:
        # Load the surface file
        surf = nib.load(file_path)
        
        # Extract vertices (pointset) and faces (triangle indices)
        vertices = surf.agg_data('pointset')
        faces = surf.agg_data('triangle')
        
        # Form the triangles using the face indices
        triangles = vertices[faces]
        
        return vertices, faces, triangles
    except Exception as e:
        print(f"Error loading surface mesh: {e}")
        return None, None, None

def extract_landmarks(vertices, y_value=-28, z_value=32):
    """
    Extract landmarks at the specified Y and Z coordinates.
    
    Parameters:
        vertices (numpy.ndarray): Array of vertices.
        y_value (float): Y-coordinate for the landmark.
        z_value (float): Z-coordinate for the landmark.
    
    Returns:
        list: List of tuples containing (x, y, z) coordinates of the landmarks.
    """
    landmarks = []
    for vertex in vertices:
        if np.isclose(vertex[1], y_value, atol=1e-2) and np.isclose(vertex[2], z_value, atol=1e-2):
            landmarks.append(vertex)
    return landmarks

def find_closest_vertex(vertices, y_value=-28, z_value=32):
    """
    Find the closest vertex to the specified Y and Z coordinates.
    
    Parameters:
        vertices (numpy.ndarray): Array of vertices.
        y_value (float): Y-coordinate for the landmark.
        z_value (float): Z-coordinate for the landmark.
    
    Returns:
        numpy.ndarray: The closest vertex (x, y, z).
    """
    # Calculate the Euclidean distance in (y, z) space
    distances = np.sqrt((vertices[:, 1] - y_value) ** 2 + (vertices[:, 2] - z_value) ** 2)
    
    # Find the index of the closest vertex
    closest_index = np.argmin(distances)
    
    return vertices[closest_index]

def display_landmarks(landmarks, closest_vertex):
    """
    Display the full (x, y, z) coordinates of the landmarks or the closest vertex.
    
    Parameters:
        landmarks (list): List of tuples containing (x, y, z) coordinates of the landmarks.
        closest_vertex (numpy.ndarray): The closest vertex (x, y, z).
    """
    if landmarks:
        print(f"Landmarks at (x, -28, 32):")
        for i, landmark in enumerate(landmarks):
            print(f"Landmark {i + 1}: (x, y, z) = {landmark}")
    else:
        print("No landmarks found at the specified coordinates.")
        print(f"Closest vertex to (y, z) = (-28, 32): (x, y, z) = {closest_vertex}")

def process_directory(directory_path):
    """
    Process all surface mesh files in a directory.
    
    Parameters:
        directory_path (str): Path to the directory containing surface mesh files.
    """
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        if os.path.isfile(file_path) and file_name.endswith(".gii"):
            print(f"\nProcessing file: {file_name}")
            vertices, faces, triangles = load_surface_mesh(file_path)
            if vertices is not None:
                print(f"{file_name} - Vertices shape: {vertices.shape}, Faces shape: {faces.shape}, Triangles shape: {triangles.shape}")
                
                # Extract landmarks at (x, -28, 32)
                landmarks = extract_landmarks(vertices)
                
                # Find the closest vertex if no landmarks are found
                closest_vertex = find_closest_vertex(vertices)
                
                # Display the full (x, y, z) coordinates of the landmarks or the closest vertex
                display_landmarks(landmarks, closest_vertex)
            else:
                print(f"Failed to load {file_name}")

# Example usage
if __name__ == "__main__":
    directory_path = r'D:\新生儿 dHCP 数据\session_1'
    process_directory(directory_path)