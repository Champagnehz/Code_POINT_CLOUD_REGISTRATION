import nibabel as nib
import numpy as np
import os
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def load_surface_mesh(file_path):
    """
    Load a surface mesh from a given file using nibabel.
    
    Parameters:
        file_path (str): Path to the surface mesh file.
    
    Returns:
        tuple: vertices (numpy.ndarray), faces (numpy.ndarray), triangles (numpy.ndarray)
    """
    try:
        # Load the surface file
        surf = nib.load(file_path)
        
        # Extract vertices (pointset) and faces (triangle indices)
        vertices = surf.agg_data('pointset')
        faces = surf.agg_data('triangle')
        
        # Form the triangles using the face indices
        triangles = vertices[faces]
        
        return vertices, faces, triangles
    except Exception as e:
        print(f"Error loading surface mesh: {e}")
        return None, None, None

def extract_landmarks(vertices, y_value=-28, z_value=32):
    """
    Extract landmarks at the specified Y and Z coordinates.
    
    Parameters:
        vertices (numpy.ndarray): Array of vertices.
        y_value (float): Y-coordinate for the landmark.
        z_value (float): Z-coordinate for the landmark.
    
    Returns:
        list: List of tuples containing (x, y, z) coordinates of the landmarks.
    """
    landmarks = []
    for vertex in vertices:
        if np.isclose(vertex[1], y_value, atol=1e-2) and np.isclose(vertex[2], z_value, atol=1e-2):
            landmarks.append(vertex)
    return landmarks

def find_closest_vertex(vertices, y_value=-28, z_value=32):
    """
    Find the closest vertex to the specified Y and Z coordinates.
    
    Parameters:
        vertices (numpy.ndarray): Array of vertices.
        y_value (float): Y-coordinate for the landmark.
        z_value (float): Z-coordinate for the landmark.
    
    Returns:
        numpy.ndarray: The closest vertex (x, y, z).
    """
    # Calculate the Euclidean distance in (y, z) space
    distances = np.sqrt((vertices[:, 1] - y_value) ** 2 + (vertices[:, 2] - z_value) ** 2)
    
    # Find the index of the closest vertex
    closest_index = np.argmin(distances)
    
    return vertices[closest_index]

def process_directory(directory_path):
    """
    Process all surface mesh files in a directory.
    
    Parameters:
        directory_path (str): Path to the directory containing surface mesh files.
    
    Returns:
        list: List of landmarks or closest vertices for each file.
    """
    results = []
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        if os.path.isfile(file_path) and file_name.endswith(".gii"):
            print(f"\nProcessing file: {file_name}")
            vertices, faces, triangles = load_surface_mesh(file_path)
            if vertices is not None:
                print(f"{file_name} - Vertices shape: {vertices.shape}, Faces shape: {faces.shape}, Triangles shape: {triangles.shape}")
                
                # Extract landmarks at (x, -28, 32)
                landmarks = extract_landmarks(vertices)
                
                if landmarks:
                    results.extend(landmarks)
                    print(f"Found {len(landmarks)} landmarks in {file_name}.")
                else:
                    # Find the closest vertex if no landmarks are found
                    closest_vertex = find_closest_vertex(vertices)
                    results.append(closest_vertex)
                    print(f"No landmarks found in {file_name}. Closest vertex: {closest_vertex}")
            else:
                print(f"Failed to load {file_name}")
    return results

def plot_all_results(results):
    """
    Plot all landmarks or closest vertices in a single 3D scatter plot.
    
    Parameters:
        results (list): List of landmarks or closest vertices.
    """
    if not results:
        print("No results to plot.")
        return
    
    # Convert results to a numpy array
    results = np.array(results)
    
    # Create a 3D plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot all points
    ax.scatter(results[:, 0], results[:, 1], results[:, 2], c='b', marker='o', label='Landmarks/Closest Vertices')
    
    # Set labels
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('3D Landmarks and Closest Vertices for All Files')
    ax.legend()
    
    # Show the plot
    plt.show()

# Example usage
if __name__ == "__main__":
    directory_path = r'C:\Users\User\Desktop\group project\新生儿 dHCP 数据\session_1'
    
    # Process all files in the directory
    results = process_directory(directory_path)
    
    # Plot all results in a single 3D plot
    plot_all_results(results)